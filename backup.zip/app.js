require('dotenv').config();
const express = require('express');
const connectDb = require('./database');
const userRoutes = require('./Routes/userRoutes');
const templateRoutes = require('./Routes/templateRoutes');
const adminRoutes = require('./Routes/adminRoutes');
const port =process.env.PORT || 3000;
const app = express();

connectDb();
app.get("/",(req,res)=>{
    res.send("<h1 style='text-align:center;padding-top:250px'>Welcome to Cloud202</h1>");
})
app.use(express.json());

app.use('/api',userRoutes);
app.use('/api',templateRoutes);

app.use(adminRoutes);
// console.log(process.env.PORT);
app.listen(port,()=>{
    console.log(`Connected to port ${port}`);
})